import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:3001/api/employee/profile', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setProfile(response.data);
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="profile-container">
      <div className="profile-header">
        <Link to="/dashboard" className="back-btn">← Back to Dashboard</Link>
        <h2>Employee Profile</h2>
      </div>
      {profile && (
        <div className="profile-card">
          <div className="profile-field">
            <label>Employee ID:</label>
            <span>{profile.employeeId}</span>
          </div>
          <div className="profile-field">
            <label>Name:</label>
            <span>{profile.name}</span>
          </div>
          <div className="profile-field">
            <label>Email:</label>
            <span>{profile.email}</span>
          </div>
          <div className="profile-field">
            <label>Department:</label>
            <span>{profile.department}</span>
          </div>
          <div className="profile-field">
            <label>Position:</label>
            <span>{profile.position}</span>
          </div>
          <div className="profile-field">
            <label>Join Date:</label>
            <span>{new Date(profile.joinDate).toLocaleDateString()}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;