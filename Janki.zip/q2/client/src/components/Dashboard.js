import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Employee Dashboard</h1>
        <div className="user-info">
          <span>Welcome, {user.name}</span>
          <button onClick={handleLogout} className="logout-btn">Logout</button>
        </div>
      </header>
      <nav className="dashboard-nav">
        <Link to="/profile" className="nav-link">Profile</Link>
        <Link to="/leave" className="nav-link">Leave Application</Link>
      </nav>
      <main className="dashboard-content">
        <div className="card">
          <h3>Quick Actions</h3>
          <Link to="/profile" className="action-btn">View Profile</Link>
          <Link to="/leave" className="action-btn">Apply for Leave</Link>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;