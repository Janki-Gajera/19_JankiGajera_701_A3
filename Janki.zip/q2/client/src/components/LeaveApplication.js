import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const LeaveApplication = () => {
  const [formData, setFormData] = useState({ date: '', reason: '' });
  const [leaves, setLeaves] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchLeaves();
  }, []);

  const fetchLeaves = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:3001/api/leave', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setLeaves(response.data);
    } catch (error) {
      console.error('Error fetching leaves:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:3001/api/leave', formData, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMessage('Leave application submitted successfully');
      setFormData({ date: '', reason: '' });
      fetchLeaves();
    } catch (error) {
      setMessage('Error submitting leave application');
    }
  };

  return (
    <div className="leave-container">
      <div className="leave-header">
        <Link to="/dashboard" className="back-btn">← Back to Dashboard</Link>
        <h2>Leave Application</h2>
      </div>
      
      <div className="leave-form-section">
        <h3>Apply for Leave</h3>
        <form onSubmit={handleSubmit} className="leave-form">
          {message && <div className="message">{message}</div>}
          <input
            type="date"
            value={formData.date}
            onChange={(e) => setFormData({...formData, date: e.target.value})}
            required
          />
          <textarea
            placeholder="Reason for leave"
            value={formData.reason}
            onChange={(e) => setFormData({...formData, reason: e.target.value})}
            required
          />
          <button type="submit">Submit Application</button>
        </form>
      </div>

      <div className="leave-list-section">
        <h3>My Leave Applications</h3>
        <div className="leave-list">
          {leaves.map((leave) => (
            <div key={leave._id} className="leave-item">
              <div className="leave-date">{new Date(leave.date).toLocaleDateString()}</div>
              <div className="leave-reason">{leave.reason}</div>
              <div className={`leave-status ${leave.status}`}>{leave.status}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LeaveApplication;